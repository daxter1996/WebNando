<footer class="page-footer blue" style="margin-top: 0;">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">Blue Beach</h5>
                <p class="grey-text text-lighten-4">
                    <?php echo $textos["telefono"][$_COOKIE["langcookie"]];?> <strong>+34 685670969</strong> <br/>
                    Email: <strong>info@bluebeach.com</strong>
                    <div>
                    </div>
                </p>
            </div>
            <div class="col l4 offset-l2 s12">
                <ul>
                    <li><a class="grey-text text-lighten-3" href="bluebeach.php">Blue Beach</a></li>
                    <li><a class="grey-text text-lighten-3" href="bluebeach2.php">Blue Beach 2</a></li>
                    <br/>
                    <a href="https://www.facebook.com/profile.php?id=100009458311409&fref=ts" target="_blank"><img src="img/icon-facebook.png" style="height: 70px"></a>
                    <a href="https://www.facebook.com/profile.php?id=100009458311409&fref=ts" target="_blank"><img src="img/icon-booking.png" style="height: 71px"></a>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright ">
        <div class="container">
            © Apartamentos Blue Beach
        </div>
    </div>
</footer>

